def check_in(vehicle_id, location):
    return {
        "vehicle_id": vehicle_id,
        "status": "available",
        "location": location
    }